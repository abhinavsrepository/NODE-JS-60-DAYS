<?php
learn_press_admin_view( 'tools/course/html-install-sample-data' );
learn_press_admin_view( 'tools/course/html-course' );
learn_press_admin_view( 'tools/course/html-user' );
learn_press_admin_view( 'tools/course/html-user-item' );
