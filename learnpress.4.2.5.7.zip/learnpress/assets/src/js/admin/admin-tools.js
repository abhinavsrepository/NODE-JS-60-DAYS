import assignUserCourse from './tools/assign-user-course';

assignUserCourse();
