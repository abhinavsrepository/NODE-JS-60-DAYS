<?php
/**
 * Elementor Controls for skin Courses List.
 *
 * @since 4.2.5.7
 * @version 1.0.0
 */

/**
 * @var LearnPress\ExternalPlugin\Elementor\Widgets\Course\Skins\CoursesList $CoursesList
 */
if ( ! isset( $CoursesList ) ) {
	return;
}
